#!/bin/bash
java SQLParser